package com.company;

//interface para implementar o voo dos animais que voam
public interface Voo {
    //metodo que sera implementado pelas classes pato e morcego
    public void animalVoo();
}
