package com.company;

//Essa classe e uma subclasse da superclasse animal.
public abstract class Ave extends Animal {

    //Atributo das aves
    private String corPena;

    //Construtor dos atributos que serao concretizados pelas suas subclasses
    public Ave(int idade, double tamanho, String corPena) {
        super(idade, tamanho);
        this.corPena = corPena;
    }

    //Getter e setter dos atributos das aves
    public String getCorPena() {
        return corPena;
    }
    public void setCorPena(String corPena) {
        this.corPena = corPena;
    }

    //metodo proprio das aves e que serao transmitidos as classes herdeiras
    public abstract void botarOvo();
}