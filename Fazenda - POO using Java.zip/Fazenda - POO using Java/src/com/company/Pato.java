package com.company;

//Essa classe e uma subclasse da superclasse ave
public class Pato extends Ave implements Voo {

    //Atributo de definicao da altitude do voo (interface) do morcego
    private int altitude;

    //atributos gerais que se aplicam a todos os objetos dessa classe
    public Pato(int idade, double tamanho, String corPena, int altitude) {
        super(idade, tamanho, corPena);
        this.altitude = altitude;
    }

    //Getter e setter do atributo de altitude
    public int getAltitude() {
        return altitude;
    }
    public void setAltitude(int altitude) {
        this.altitude = altitude;
    }

    //metodo utilizado para informar ao usuario as informacoes atribuidas a cada variavel
    public void informacaoPato(){
        System.out.println("\n");
        System.out.println("***Novo animal cadastrado com sucesso!***");
        System.out.println("\n");
        System.out.println("A idade do pato é " + this.getIdade() + " anos.");
        System.out.println("O tamanho do pato é " + this.getTamanho() + " centímetros.");
        System.out.println("A cor do pato é " + this.getCorPena() + ".");
    }

    //Método herdado da classe Animal
    public void somAnimal() {
        System.out.print("O pato grasna e diz: Quac, quac.\n");
    }

    //Método herdado da classe Ave
    public void botarOvo(){
        System.out.print("Ele botou um ovo.\n");
    }

    //Método implementado pela classe que sera completa com o input do valor de altitude
    public void animalVoo() {
        System.out.println("A altitude de voo deste pato é " + this.getAltitude() + " metros.\n");
    }
}