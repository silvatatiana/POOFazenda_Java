package com.company;

//Essa classe e uma subclasse da superclasse mamifero
public class Vaca extends Mamifero {

    //atributos gerais que se aplicam a todos os objetos dessa classe
    public Vaca(int idade, double tamanho, String corPelo) {
        super(idade, tamanho, corPelo);
    }

    //metodo utilizado para informar ao usuario as informacoes atribuidas a cada variavel
    public void informacaoVaca(){
        System.out.println("\n");
        System.out.println("***Novo animal cadastrado com sucesso!***");
        System.out.println("\n");
        System.out.println("A idade da vaca é " + this.getIdade() + " anos.");
        System.out.println("O tamanho da vaca é " + this.getTamanho() + " centímetros.");
        System.out.println("A cor da vaca é " + this.getCorPelo() + ".");
    }
    //Método herdado da classe Animal
    public void somAnimal() {
        System.out.print("A vaca muge e diz: Muuuu.\n");
    }

    //Método herdado da classe Mamifero
    public void amamentar(){
        System.out.print("Ela amamenta seus filhotes.\n");
    }
}