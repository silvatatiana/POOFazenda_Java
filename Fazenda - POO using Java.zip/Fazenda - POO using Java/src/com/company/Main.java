package com.company;
import java.util.Scanner;
//classe main criada para inicializar o projeto
public class Main {

    public static void main(String []args)
    {
        String input = null;
        Scanner scanner = new Scanner(System.in);
        //inicio do menu de selecao do tipo de animal, entre as classes galinha, pato, vaca e morcego
        boolean inmenu = true;
        while(inmenu){
            System.out.println("***Bem-vindo(a) ao sistema de cadastro de animais da Fazenda!!!***");
            System.out.println("*************Para iniciar, selecione um novo animal.**************");
            System.out.println("Para começar, selecione uma opção:");
            System.out.println("1 - Galinha");
            System.out.println("2 - Pato");
            System.out.println("3 - Vaca");
            System.out.println("4 - Morcego");
            System.out.println("0 - Sair");
            int op = scanner.nextInt();
            switch (op) {

                /*opcao 1, cria a galinha com todos os atributos e metodos definidos na propria classe ou nas suas
                superclasses*/
                case 1:
                    System.out.println("Você selecionou uma galinha.");
                    Galinha galinha1 = new Galinha(op, op, input);
                    System.out.println("Quantos anos ela tem (em anos)? ");
                    galinha1.setIdade (scanner.nextInt());
                    System.out.println("Qual é o seu tamanho (em centímetros)? ");
                    galinha1.setTamanho (scanner.nextDouble());
                    System.out.println("Qual é a sua cor? ");
                    galinha1.setCorPena (scanner.next());
                    galinha1.informacaoGalinha();
                    galinha1.somAnimal();
                    galinha1.botarOvo();
                    System.out.println("###Fim do cadastro!###");
                    inmenu=false;
                    break;

                /*opcao 2, cria o pato com todos os atributos e metodos definidos na propria classe ou nas suas
                superclasses*/
                case 2:
                    System.out.println("Você selecionou um pato.");
                    Pato pato1 = new Pato(op, op, input, op);
                    System.out.println("Quantos anos ele tem (em anos)? ");
                    pato1.setIdade (scanner.nextInt());
                    System.out.println("Qual é o seu tamanho (em centímetros)? ");
                    pato1.setTamanho (scanner.nextDouble());
                    System.out.println("Qual é a sua cor? ");
                    pato1.setCorPena (scanner.next());
                    System.out.println("Qual é a sua altitude de voo (em metros)? ");
                    pato1.setAltitude (scanner.nextInt());
                    pato1.informacaoPato();
                    pato1.somAnimal();
                    pato1.botarOvo();
                    pato1.animalVoo();
                    System.out.println("###Fim do cadastro!###");
                    inmenu=false;
                    break;

                /*opcao 3, cria a vaca com todos os atributos e metodos definidos na propria classe ou nas suas
                superclasses*/
                case 3:
                    System.out.println("Você selecionou uma vaca.");
                    Vaca vaca1 = new Vaca(op, op, input);
                    System.out.println("Quantos anos ela tem (em anos)? ");
                    vaca1.setIdade (scanner.nextInt());
                    System.out.println("Qual é o seu tamanho (em centímetros)? ");
                    vaca1.setTamanho (scanner.nextDouble());
                    System.out.println("Qual é a sua cor? ");
                    vaca1.setCorPelo (scanner.next());
                    vaca1.informacaoVaca();
                    vaca1.somAnimal();
                    vaca1.amamentar();
                    System.out.println("###Fim do cadastro!###");
                    inmenu=false;
                    break;

                 /*opcao 4, cria o morcego com todos os atributos e metodos definidos na propria classe ou nas suas
                superclasses*/
                case 4:
                    System.out.println("Você selecionou um morcego.");
                    Morcego morcego1 = new Morcego(op, op, input, op);
                    System.out.println("Quantos anos ele tem (em anos)? ");
                    morcego1.setIdade (scanner.nextInt());
                    System.out.println("Qual é o seu tamanho (em centímetros)? ");
                    morcego1.setTamanho (scanner.nextDouble());
                    System.out.println("Qual é a sua cor? ");
                    morcego1.setCorPelo (scanner.next());
                    System.out.println("Qual é a sua altitude de voo (em metros)? ");
                    morcego1.setAltitude (scanner.nextInt());
                    morcego1.informacaoMorcego();
                    morcego1.somAnimal();
                    morcego1.amamentar();
                    morcego1.animalVoo();
                    System.out.println("###Fim do cadastro!###");
                    inmenu=false;
                    break;
                case 0:
                    System.out.println("saindo");
                    inmenu=false;
                    break;
                default:
                    System.out.println("Operacao invalida!");
            }
        }
    }
}