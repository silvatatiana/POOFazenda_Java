package com.company;

//Essa classe e uma subclasse da superclasse ave
public class Galinha extends Ave {

    //atributos gerais que se aplicam a todos os objetos dessa classe
    public Galinha(int idade, double tamanho, String corPena) {
        super(idade, tamanho, corPena);
    }

    //metodo utilizado para informar ao usuario as informacoes atribuidas a cada variavel
    public void informacaoGalinha(){
        System.out.println("\n");
        System.out.println("***Novo animal cadastrado com sucesso!***");
        System.out.println("\n");
        System.out.println("A idade da galinha é " + this.getIdade() + " anos.");
        System.out.println("O tamanho da galinha é " + this.getTamanho() + " centímetros.");
        System.out.println("A cor da galinha é " + this.getCorPena() + ".");
    }
    //Método herdado da classe Animal
    public void somAnimal() {
        System.out.print("A galinha cacareja e diz: Cocoricocó.\n");
    }
    //Método herdado da classe Ave
    public void botarOvo(){
        System.out.print("Ela botou um ovo.\n");
    }
}