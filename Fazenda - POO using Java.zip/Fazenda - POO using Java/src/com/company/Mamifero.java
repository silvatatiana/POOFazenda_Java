package com.company;

//Essa classe e uma subclasse da superclasse animal.
public abstract class Mamifero extends Animal {

    //Atributo dos mamiferos
    private String corPelo;

    //Construtor dos atributos que serao concretizados pelas suas subclasses
    public Mamifero(int idade, double tamanho, String corPelo) {
        super(idade, tamanho);
        this.corPelo = corPelo;
    }

    //Getter e setter dos atributos dos mamiferos
    public String getCorPelo() {
        return corPelo;
    }
    public void setCorPelo(String corPelo) {
        this.corPelo = corPelo;
    }

    //metodo proprio dos mamiferos e que serao transmitidos as subclasses
    public abstract void amamentar();
}