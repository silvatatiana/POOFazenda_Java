package com.company;

// Classe Abstrata com atributos e metodos que serao aplicados as subclasses.
public abstract class Animal {

    //atributos da classe
    private int idade;
    private double tamanho;

    //Construtor
    public Animal(int idade, double tamanho){
        this.idade = idade;
        this.tamanho = tamanho;
    }

    //Getter e Setter relacionados a idade.
    public int getIdade() {
        return idade;
    }
    public void setIdade(int idade) {
        this.idade = idade;
    }

    //Getter e Setter relacionados ao tamanho.
    public double getTamanho() {
        return tamanho;
    }
    public void setTamanho(double tamanho) {
        this.tamanho = tamanho;
    }

    //metodo da classe animal
    public abstract void somAnimal();

    //Descriçao do Animal
    public String toString() {
        return "A idade é "+ idade + "." + "e o tamanho é " + tamanho + ".";
    }
}