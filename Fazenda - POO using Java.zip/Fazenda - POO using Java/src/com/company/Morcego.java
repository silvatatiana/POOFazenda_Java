package com.company;

//Essa classe e uma subclasse da superclasse mamifero
public class Morcego extends Mamifero implements Voo {

    //Atributo de definicao da altitude do voo (interface) do morcego
    private int altitude;

    //atributos gerais que se aplicam a todos os objetos dessa classe
    public Morcego(int idade, double tamanho, String corPelo, int altitude) {
        super(idade, tamanho, corPelo);
        this.altitude = altitude;
    }

    //Getter e setter do atributo de altitude
    public int getAltitude() {
        return altitude;
    }
    public void setAltitude(int altitude) {
        this.altitude = altitude;
    }

    //metodo utilizado para informar ao usuario as informacoes atribuidas a cada variavel
    public void informacaoMorcego(){
        System.out.println("\n");
        System.out.println("***Novo animal cadastrado com sucesso!***");
        System.out.println("\n");
        System.out.println("A idade do morcego é " + this.getIdade() + " anos.");
        System.out.println("O tamanho do morcego é " + this.getTamanho() + " centímetros.");
        System.out.println("A cor do morcego é " + this.getCorPelo() + ".");
    }

    //Método herdado da classe Animal
    public void somAnimal() {
        System.out.print("O morcego farfalha e diz: Fru, Fru.\n");
    }

    //Método herdado da classe Mamifero
    public void amamentar(){
        System.out.print("Ele amamenta seus filhotes.\n");
    }

    //Método implementado pela classe que sera completa com o input do valor de altitude
    public void animalVoo() {
        System.out.println("A altitude de voo deste morcego é " + this.getAltitude() + " metros.\n");
    }
}